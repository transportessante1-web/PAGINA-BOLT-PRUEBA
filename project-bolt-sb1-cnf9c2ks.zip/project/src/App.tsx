import React, { useState } from 'react';
import { Phone, Clock, MapPin, Truck, Wrench, Shield, Star, Menu, X, CheckCircle } from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-black shadow-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-blue-600 to-red-600 p-2 rounded-lg">
                <Truck className="h-6 w-6 text-white" />
              </div>
              <span className="text-white text-xl font-bold">
                M<span className="text-blue-500">Grúas</span>
              </span>
            </div>
            
            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              <a href="#inicio" className="text-white hover:text-blue-400 transition-colors duration-200">Inicio</a>
              <a href="#servicios" className="text-white hover:text-blue-400 transition-colors duration-200">Servicios</a>
              <a href="#contacto" className="text-white hover:text-blue-400 transition-colors duration-200">Contacto</a>
              <a href="#numeros" className="bg-gradient-to-r from-red-600 to-red-700 text-white px-4 py-2 rounded-md hover:from-red-700 hover:to-red-800 transition-all duration-200">
                Emergencias
              </a>
            </nav>

            {/* Mobile menu button */}
            <button 
              className="md:hidden text-white"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-gray-900">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <a href="#inicio" className="block text-white hover:text-blue-400 px-3 py-2">Inicio</a>
              <a href="#servicios" className="block text-white hover:text-blue-400 px-3 py-2">Servicios</a>
              <a href="#contacto" className="block text-white hover:text-blue-400 px-3 py-2">Contacto</a>
              <a href="#numeros" className="block bg-red-600 text-white px-3 py-2 rounded-md">Emergencias</a>
            </div>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section id="inicio" className="relative bg-gradient-to-br from-blue-900 via-gray-900 to-black text-white overflow-hidden">
        <div className="absolute inset-0 bg-black/60 z-10"></div>
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: 'url(/image1%20(1).jpeg)' }}
        ></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center relative z-20">
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Servicio de Grúas
              <span className="bg-gradient-to-r from-blue-400 to-red-400 bg-clip-text text-transparent block">
                24/7
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto">
              Asistencia vial profesional con la confiabilidad y precisión que caracteriza a los mejores.
              Estamos aquí cuando nos necesitas.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="#numeros" className="bg-gradient-to-r from-red-600 to-red-700 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:from-red-700 hover:to-red-800 transform hover:scale-105 transition-all duration-200 shadow-lg">
                Llamar Ahora
              </a>
              <a href="#servicios" className="bg-transparent border-2 border-blue-500 text-blue-400 px-8 py-3 rounded-lg text-lg font-semibold hover:bg-blue-500 hover:text-white transition-all duration-200">
                Ver Servicios
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Emergency Numbers Section */}
      <section id="numeros" className="relative py-16 bg-gradient-to-r from-red-600 to-red-700 overflow-hidden">
        <div className="absolute inset-0 bg-red-600/80 z-10"></div>
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: 'url(/image3.jpeg)' }}
        ></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 relative z-20">
            <h2 className="text-4xl font-bold text-white mb-4">Números de Emergencia</h2>
            <p className="text-red-100 text-lg">Disponible las 24 horas, los 7 días de la semana</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative z-20">
            <div className="bg-white rounded-xl p-8 text-center shadow-2xl transform hover:scale-105 transition-all duration-200">
              <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Phone className="h-8 w-8 text-red-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Emergencias</h3>
              <p className="text-3xl font-bold text-red-600 mb-2">911-GRUAS</p>
              <p className="text-gray-600">Disponible 24/7</p>
            </div>
            
            <div className="bg-white rounded-xl p-8 text-center shadow-2xl transform hover:scale-105 transition-all duration-200">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Servicio Programado</h3>
              <p className="text-3xl font-bold text-blue-600 mb-2">555-0123</p>
              <p className="text-gray-600">Lun-Dom 8:00-20:00</p>
            </div>
            
            <div className="bg-white rounded-xl p-8 text-center shadow-2xl transform hover:scale-105 transition-all duration-200">
              <div className="bg-gray-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="h-8 w-8 text-gray-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">WhatsApp</h3>
              <p className="text-3xl font-bold text-green-600 mb-2">555-0124</p>
              <p className="text-gray-600">Mensajes y ubicación</p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="servicios" className="relative py-20 bg-gray-50 overflow-hidden">
        <div className="absolute inset-0 bg-white/90 z-10"></div>
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
          style={{ backgroundImage: 'url(/image4.jpeg)' }}
        ></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 relative z-20">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Nuestros Servicios</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Ofrecemos servicios profesionales de grúa con equipos modernos y personal capacitado
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 relative z-20">
            <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 border-l-4 border-blue-600">
              <div className="bg-blue-100 w-12 h-12 rounded-lg flex items-center justify-center mb-6">
                <Truck className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-4">Grúa de Plataforma</h3>
              <p className="text-gray-600 mb-4">Transporte seguro de vehículos con nuestra flota de grúas de plataforma moderna.</p>
              <ul className="space-y-2">
                <li className="flex items-center text-gray-600">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Vehículos de lujo
                </li>
                <li className="flex items-center text-gray-600">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Transporte seguro
                </li>
              </ul>
            </div>
            
            <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 border-l-4 border-red-600">
              <div className="bg-red-100 w-12 h-12 rounded-lg flex items-center justify-center mb-6">
                <Wrench className="h-6 w-6 text-red-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-4">Asistencia Mecánica</h3>
              <p className="text-gray-600 mb-4">Servicios de mecánica básica en el lugar del incidente.</p>
              <ul className="space-y-2">
                <li className="flex items-center text-gray-600">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Cambio de llantas
                </li>
                <li className="flex items-center text-gray-600">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Carga de batería
                </li>
              </ul>
            </div>
            
            <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 border-l-4 border-gray-600">
              <div className="bg-gray-100 w-12 h-12 rounded-lg flex items-center justify-center mb-6">
                <Shield className="h-6 w-6 text-gray-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-4">Servicio de Emergencia</h3>
              <p className="text-gray-600 mb-4">Respuesta rápida las 24 horas del día, todos los días del año.</p>
              <ul className="space-y-2">
                <li className="flex items-center text-gray-600">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Respuesta en 30 min
                </li>
                <li className="flex items-center text-gray-600">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Personal certificado
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Lo Que Dicen Nuestros Clientes</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-gray-50 rounded-xl p-8 shadow-lg">
              <div className="flex items-center mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                ))}
              </div>
              <p className="text-gray-600 mb-4">"Servicio excelente y muy rápido. Llegaron en menos de 20 minutos y trataron mi coche con mucho cuidado."</p>
              <p className="font-semibold text-gray-800">- María González</p>
            </div>
            
            <div className="bg-gray-50 rounded-xl p-8 shadow-lg">
              <div className="flex items-center mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                ))}
              </div>
              <p className="text-gray-600 mb-4">"Personal muy profesional y precios justos. Los recomiendo totalmente."</p>
              <p className="font-semibold text-gray-800">- Carlos Rodríguez</p>
            </div>
            
            <div className="bg-gray-50 rounded-xl p-8 shadow-lg">
              <div className="flex items-center mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                ))}
              </div>
              <p className="text-gray-600 mb-4">"Disponibles 24/7 como prometen. Me ayudaron un domingo por la madrugada sin problemas."</p>
              <p className="font-semibold text-gray-800">- Ana Martín</p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contacto" className="relative py-20 bg-gradient-to-br from-blue-900 to-black text-white overflow-hidden">
        <div className="absolute inset-0 bg-black/70 z-10"></div>
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: 'url(/image3.jpeg)' }}
        ></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 relative z-20">
            <div>
              <h2 className="text-4xl font-bold mb-8">Contáctanos</h2>
              <div className="space-y-6">
                <div className="flex items-center">
                  <div className="bg-blue-600 p-3 rounded-lg mr-4">
                    <Phone className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold">Teléfono</h3>
                    <p className="text-blue-200">911-GRUAS / 555-0123</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <div className="bg-red-600 p-3 rounded-lg mr-4">
                    <MapPin className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold">Ubicación</h3>
                    <p className="text-blue-200">Toda la ciudad y alrededores</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <div className="bg-gray-600 p-3 rounded-lg mr-4">
                    <Clock className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold">Horario</h3>
                    <p className="text-blue-200">24 horas, 7 días a la semana</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8">
              <form className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium mb-2">Nombre</label>
                  <input 
                    type="text" 
                    id="name"
                    className="w-full px-4 py-3 bg-white/20 border border-white/30 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-white placeholder-white/60"
                    placeholder="Tu nombre"
                  />
                </div>
                
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium mb-2">Teléfono</label>
                  <input 
                    type="tel" 
                    id="phone"
                    className="w-full px-4 py-3 bg-white/20 border border-white/30 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-white placeholder-white/60"
                    placeholder="Tu teléfono"
                  />
                </div>
                
                <div>
                  <label htmlFor="message" className="block text-sm font-medium mb-2">Mensaje</label>
                  <textarea 
                    id="message"
                    rows={4}
                    className="w-full px-4 py-3 bg-white/20 border border-white/30 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-white placeholder-white/60"
                    placeholder="Describe tu situación"
                  ></textarea>
                </div>
                
                <button 
                  type="submit"
                  className="w-full bg-gradient-to-r from-red-600 to-red-700 text-white py-3 px-6 rounded-lg font-semibold hover:from-red-700 hover:to-red-800 transition-all duration-200 transform hover:scale-105"
                >
                  Enviar Mensaje
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-3 mb-4 md:mb-0">
              <div className="bg-gradient-to-r from-blue-600 to-red-600 p-2 rounded-lg">
                <Truck className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold">
                M<span className="text-blue-500">Grúas</span>
              </span>
            </div>
            
            <div className="text-center md:text-right">
              <p className="text-gray-400 mb-2">
                © 2025 MGrúas. Todos los derechos reservados.
              </p>
              <p className="text-sm text-gray-500">
                Servicio profesional de grúas 24/7
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;